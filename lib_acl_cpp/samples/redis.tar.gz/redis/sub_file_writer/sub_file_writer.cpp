#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <list>
#include <string>
#include <stdlib.h>
using namespace std;

int main(int argc, char** argv)
{

	if(argc != 2){
		printf("Usage: [ip:port]\n");
		exit(1);
	}

	int conn_timeout = 10, rw_timeout = 0;
	acl::string addr(argv[1]);

	acl::acl_cpp_init();
	acl::log::stdout_open(true);
	acl::redis_client client(addr.c_str(), conn_timeout, rw_timeout);
	acl::redis_pubsub redis(&client);

	ofstream myfile;
	myfile.open("../txt.txt");

	redis.clear();

	acl::string channel = "channel";
	redis.subscribe(channel, NULL);

	acl::string msg;

	channel.clear();
	msg.clear();
	redis.clear();
	while(true){
		if ((redis.get_message(channel, msg)) == false)
		{
			printf("get_message error(%s)\r\n",
				redis.result_error());
			return false;
		}
		else {
			printf("write ");
			printf("%s\n", msg.c_str());
			if(myfile.is_open()){
				printf("file is open\n");
				myfile << msg.c_str() << "\n";
				myfile.flush();
			}
			else printf("not open\n");
				
		}	
	}
	myfile.close();
#ifdef WIN32
	printf("enter any key to exit\r\n");
	getchar();
#endif
	return 0;
}

